package com.project.teeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeetoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.project.teeto.intergrate.paging.mapper;

import org.springframework.stereotype.Repository;

@Repository
public interface PaginationMapper {
}
